module fountainizer.parser {

    requires fountainizer.api;
    exports at.hsol.fountainizer.parser;
}