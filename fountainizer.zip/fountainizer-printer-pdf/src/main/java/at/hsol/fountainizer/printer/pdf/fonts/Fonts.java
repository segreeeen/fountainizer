package at.hsol.fountainizer.printer.pdf.fonts;

public enum Fonts {
	CourierPrime, CourierPrimeBold, CourierPrimeBoldItalic, CourierPrimeItalic
}
