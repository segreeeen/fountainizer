module fountainizer.printer.pdf {
    requires fountainizer.api;
    requires org.apache.pdfbox;
    requires java.desktop;
    exports at.hsol.fountainizer.printer.pdf;
}