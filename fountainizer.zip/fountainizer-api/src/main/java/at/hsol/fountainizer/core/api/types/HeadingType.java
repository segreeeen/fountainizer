package at.hsol.fountainizer.core.api.types;

public enum HeadingType {
	INT, EXT, EST, INT_EXT, CUSTOM
}
