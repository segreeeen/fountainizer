package at.hsol.fountainizer.core.api.parser;

public interface Scene {
}
