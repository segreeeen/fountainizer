package at.hsol.fountainizer.core.api.parser;

public interface ParserAPI {
    Content parse(String paramString);
}
