
rootProject.name = "fountainizer"
include("fountainizer-parser-fountain")
include("fountainizer-api")
include("fountainizer-printer-pdf")
include("fountainizer-printer-html")
include("fountainizer-gui-simplegui")
